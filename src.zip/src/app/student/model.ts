export interface TestItem {
    firstName?: string;
    lastName?: string;
    streetAddress?: string;
    city?: string;
    state?: string;
    zip?: string;
    telePhone?: number;
    email?: string;
    date?: string;
    location?: string;
    campus?: string;
    sports?: string;
    dormRooms?: string;
    atmosphere?: string;
    students?: string;
    recommend?: string;
    comment?: string;
    radio?: string;
}